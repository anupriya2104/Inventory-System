'use client';
// src/components/layout/AppShell.tsx
import Sidebar from './Sidebar';

interface AppShellProps {
  children: React.ReactNode;
  orgName: string;
  userEmail: string;
}

export default function AppShell({ children, orgName, userEmail }: AppShellProps) {
  return (
    <div style={{ display: 'flex' }}>
      <Sidebar orgName={orgName} userEmail={userEmail} />
      <main className="main-content" style={{ flex: 1 }}>
        {children}
      </main>
    </div>
  );
}
