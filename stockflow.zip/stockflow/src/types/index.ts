// src/types/index.ts

export interface Product {
  id: string;
  organizationId: string;
  name: string;
  sku: string;
  description?: string | null;
  quantityOnHand: number;
  costPrice?: number | null;
  sellingPrice?: number | null;
  lowStockThreshold?: number | null;
  createdAt: string;
  updatedAt: string;
  isLowStock?: boolean;
}

export interface DashboardData {
  totalProducts: number;
  totalQuantity: number;
  lowStockItems: Product[];
  orgName: string;
  defaultThreshold: number;
}

export interface OrgSettings {
  defaultLowStockThreshold: number;
}

export interface User {
  id: string;
  email: string;
  organizationId: string;
  organization: {
    id: string;
    name: string;
    settings?: OrgSettings | null;
  };
}
