// src/app/products/[id]/edit/page.tsx
import { redirect, notFound } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import AppShell from '@/components/layout/AppShell';
import ProductForm from '../../ProductForm';

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) redirect('/login');

  const [org, product] = await Promise.all([
    prisma.organization.findUnique({ where: { id: session.orgId } }),
    prisma.product.findFirst({
      where: { id: params.id, organizationId: session.orgId, deletedAt: null }
    }),
  ]);

  if (!product) notFound();

  const serialized = {
    ...product,
    createdAt: product.createdAt.toISOString(),
    updatedAt: product.updatedAt.toISOString(),
  };

  return (
    <AppShell orgName={org?.name || ''} userEmail={session.email}>
      <ProductForm mode="edit" product={serialized} />
    </AppShell>
  );
}
