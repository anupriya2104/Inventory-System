// src/app/products/new/page.tsx
import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import AppShell from '@/components/layout/AppShell';
import ProductForm from '../ProductForm';

export default async function NewProductPage() {
  const session = await getSession();
  if (!session) redirect('/login');

  const org = await prisma.organization.findUnique({ where: { id: session.orgId } });

  return (
    <AppShell orgName={org?.name || ''} userEmail={session.email}>
      <ProductForm mode="create" />
    </AppShell>
  );
}
