'use client';
// src/app/products/ProductsClient.tsx
import { useState, useMemo, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Package, Search, Plus, Edit2, Trash2, ArrowUpDown } from 'lucide-react';
import { Product } from '@/types';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import Toast from '@/components/ui/Toast';
import AdjustStockModal from './AdjustStockModal';

interface Props {
  initialProducts: Product[];
  defaultThreshold: number;
}

export default function ProductsClient({ initialProducts, defaultThreshold }: Props) {
  const router = useRouter();
  const [products, setProducts] = useState(initialProducts);
  const [search, setSearch] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [adjustProduct, setAdjustProduct] = useState<Product | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [sortBy, setSortBy] = useState<'name' | 'qty' | 'sku'>('name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const showToast = useCallback((message: string, type: 'success' | 'error') => {
    setToast({ message, type });
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let list = products.filter(p =>
      !q || p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)
    );
    list = [...list].sort((a, b) => {
      let cmp = 0;
      if (sortBy === 'name') cmp = a.name.localeCompare(b.name);
      if (sortBy === 'sku') cmp = a.sku.localeCompare(b.sku);
      if (sortBy === 'qty') cmp = a.quantityOnHand - b.quantityOnHand;
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return list;
  }, [products, search, sortBy, sortDir]);

  function toggleSort(col: typeof sortBy) {
    if (sortBy === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortBy(col); setSortDir('asc'); }
  }

  async function handleDelete() {
    if (!deleteId) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/products/${deleteId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setProducts(ps => ps.filter(p => p.id !== deleteId));
        showToast('Product deleted', 'success');
      } else {
        showToast(data.error || 'Delete failed', 'error');
      }
    } catch {
      showToast('Network error', 'error');
    } finally {
      setDeleting(false);
      setDeleteId(null);
    }
  }

  function handleAdjusted(updated: Product) {
    const threshold = updated.lowStockThreshold ?? defaultThreshold;
    setProducts(ps => ps.map(p => p.id === updated.id
      ? { ...updated, isLowStock: updated.quantityOnHand <= threshold }
      : p
    ));
    setAdjustProduct(null);
    showToast('Stock adjusted', 'success');
  }

  const SortIcon = ({ col }: { col: typeof sortBy }) => (
    <ArrowUpDown size={12} style={{ opacity: sortBy === col ? 1 : 0.3 }} />
  );

  return (
    <>
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: 'var(--ink)', margin: 0, marginBottom: 4 }}>
              Products
            </h1>
            <p style={{ fontSize: 14, color: 'var(--ink-faint)', margin: 0 }}>
              {products.length} {products.length === 1 ? 'product' : 'products'} in catalog
            </p>
          </div>
          <Link href="/products/new" className="btn btn-primary">
            <Plus size={16} />
            Add Product
          </Link>
        </div>
      </div>

      <div className="page-body">
        {/* Search */}
        <div style={{ marginBottom: 20 }}>
          <div className="search-wrapper" style={{ maxWidth: 360 }}>
            <Search size={16} className="search-icon" />
            <input
              type="text"
              className="input"
              placeholder="Search by name or SKU…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>

        {products.length === 0 ? (
          <div className="card">
            <div className="empty-state">
              <Package size={40} color="var(--border)" style={{ marginBottom: 16 }} />
              <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--ink-muted)', marginBottom: 6 }}>No products yet</div>
              <div style={{ fontSize: 14, marginBottom: 20 }}>Add your first product to get started.</div>
              <Link href="/products/new" className="btn btn-primary">
                <Plus size={16} /> Add Product
              </Link>
            </div>
          </div>
        ) : (
          <div className="card animate-fade-in">
            <div className="table-container" style={{ border: 'none', borderRadius: 12 }}>
              <table>
                <thead>
                  <tr>
                    <th>
                      <button
                        onClick={() => toggleSort('name')}
                        style={{ display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', cursor: 'pointer', font: 'inherit', color: 'inherit', padding: 0, fontWeight: 'inherit', letterSpacing: 'inherit', textTransform: 'inherit', fontSize: 'inherit' }}
                      >
                        Product <SortIcon col="name" />
                      </button>
                    </th>
                    <th>
                      <button
                        onClick={() => toggleSort('sku')}
                        style={{ display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', cursor: 'pointer', font: 'inherit', color: 'inherit', padding: 0, fontWeight: 'inherit', letterSpacing: 'inherit', textTransform: 'inherit', fontSize: 'inherit' }}
                      >
                        SKU <SortIcon col="sku" />
                      </button>
                    </th>
                    <th>
                      <button
                        onClick={() => toggleSort('qty')}
                        style={{ display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', cursor: 'pointer', font: 'inherit', color: 'inherit', padding: 0, fontWeight: 'inherit', letterSpacing: 'inherit', textTransform: 'inherit', fontSize: 'inherit' }}
                      >
                        Qty on Hand <SortIcon col="qty" />
                      </button>
                    </th>
                    <th>Selling Price</th>
                    <th>Stock Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={6} style={{ textAlign: 'center', color: 'var(--ink-faint)', padding: '32px 16px' }}>
                        No products match your search.
                      </td>
                    </tr>
                  ) : filtered.map(product => {
                    const threshold = product.lowStockThreshold ?? defaultThreshold;
                    const isZero = product.quantityOnHand === 0;
                    const isLow = product.quantityOnHand <= threshold;
                    return (
                      <tr key={product.id}>
                        <td>
                          <div style={{ fontWeight: 600, color: 'var(--ink)' }}>{product.name}</div>
                          {product.description && (
                            <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>
                              {product.description.length > 50 ? product.description.slice(0, 50) + '…' : product.description}
                            </div>
                          )}
                        </td>
                        <td>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, background: 'var(--paper-warm)', padding: '3px 7px', borderRadius: 4, color: 'var(--ink-muted)' }}>
                            {product.sku}
                          </span>
                        </td>
                        <td>
                          <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 15, color: isZero ? 'var(--ink-faint)' : isLow ? 'var(--crimson)' : 'var(--jade)' }}>
                            {product.quantityOnHand.toLocaleString()}
                          </span>
                        </td>
                        <td style={{ color: 'var(--ink-muted)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>
                          {product.sellingPrice != null ? `$${product.sellingPrice.toFixed(2)}` : '—'}
                        </td>
                        <td>
                          {isZero ? (
                            <span className="badge badge-zero">Out of stock</span>
                          ) : isLow ? (
                            <span className="badge badge-low-stock">Low stock</span>
                          ) : (
                            <span className="badge badge-ok">In stock</span>
                          )}
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button
                              onClick={() => setAdjustProduct(product)}
                              className="btn btn-secondary btn-sm"
                              title="Adjust stock"
                            >
                              ± Stock
                            </button>
                            <Link
                              href={`/products/${product.id}/edit`}
                              className="btn btn-ghost btn-sm"
                              title="Edit"
                            >
                              <Edit2 size={14} />
                            </Link>
                            <button
                              onClick={() => setDeleteId(product.id)}
                              className="btn btn-ghost btn-sm"
                              title="Delete"
                              style={{ color: 'var(--crimson)' }}
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {deleteId && (
        <ConfirmDialog
          title="Delete product"
          message="This will permanently remove the product from your inventory. This action cannot be undone."
          confirmLabel="Delete product"
          onConfirm={handleDelete}
          onCancel={() => setDeleteId(null)}
          loading={deleting}
        />
      )}

      {adjustProduct && (
        <AdjustStockModal
          product={adjustProduct}
          onClose={() => setAdjustProduct(null)}
          onAdjusted={handleAdjusted}
        />
      )}

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </>
  );
}
