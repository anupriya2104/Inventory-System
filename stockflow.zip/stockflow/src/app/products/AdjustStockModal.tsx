'use client';
// src/app/products/AdjustStockModal.tsx
import { useState } from 'react';
import { X, Plus, Minus } from 'lucide-react';
import { Product } from '@/types';

interface Props {
  product: Product;
  onClose: () => void;
  onAdjusted: (updated: Product) => void;
}

export default function AdjustStockModal({ product, onClose, onAdjusted }: Props) {
  const [delta, setDelta] = useState('');
  const [note, setNote] = useState('');
  const [mode, setMode] = useState<'add' | 'remove'>('add');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const numDelta = parseInt(delta) || 0;
  const actualDelta = mode === 'add' ? numDelta : -numDelta;
  const newQty = product.quantityOnHand + actualDelta;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!delta || numDelta <= 0) { setError('Enter a valid positive quantity'); return; }
    if (newQty < 0) { setError('Stock cannot go below 0'); return; }

    setLoading(true);
    try {
      const res = await fetch(`/api/products/${product.id}/adjust`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ delta: actualDelta, note }),
      });
      const data = await res.json();
      if (data.success) {
        onAdjusted(data.data);
      } else {
        setError(data.error || 'Adjustment failed');
      }
    } catch {
      setError('Network error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div style={{ padding: '24px 24px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: 'var(--ink)' }}>Adjust Stock</h2>
            <p style={{ margin: '4px 0 0', fontSize: 13, color: 'var(--ink-faint)' }}>{product.name}</p>
          </div>
          <button onClick={onClose} className="btn btn-ghost btn-sm" style={{ padding: 6 }}>
            <X size={18} />
          </button>
        </div>

        <div style={{ padding: 24 }}>
          {/* Current stock display */}
          <div style={{
            background: 'var(--paper-warm)', borderRadius: 10, padding: '16px 20px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24
          }}>
            <div>
              <div style={{ fontSize: 12, color: 'var(--ink-faint)', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 4 }}>Current Stock</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 700, color: 'var(--ink)', lineHeight: 1 }}>
                {product.quantityOnHand}
              </div>
            </div>
            {numDelta > 0 && (
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 12, color: 'var(--ink-faint)', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 4 }}>New Stock</div>
                <div style={{
                  fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 700, lineHeight: 1,
                  color: newQty < 0 ? 'var(--crimson)' : newQty === 0 ? 'var(--ink-faint)' : 'var(--jade)'
                }}>
                  {newQty}
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Mode toggle */}
            <div>
              <label className="label">Adjustment Type</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  type="button"
                  onClick={() => setMode('add')}
                  className={`btn btn-sm ${mode === 'add' ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ flex: 1 }}
                >
                  <Plus size={14} /> Add Stock
                </button>
                <button
                  type="button"
                  onClick={() => setMode('remove')}
                  className={`btn btn-sm ${mode === 'remove' ? '' : 'btn-secondary'}`}
                  style={mode === 'remove' ? { flex: 1, background: 'var(--crimson)', color: 'white', border: '1.5px solid var(--crimson)' } : { flex: 1 }}
                >
                  <Minus size={14} /> Remove Stock
                </button>
              </div>
            </div>

            <div>
              <label className="label">Quantity</label>
              <input
                type="number"
                className={`input ${error && !delta ? 'input-error' : ''}`}
                placeholder="e.g. 10"
                value={delta}
                onChange={e => setDelta(e.target.value)}
                min={1}
                autoFocus
              />
            </div>

            <div>
              <label className="label">Note <span style={{ color: 'var(--ink-faint)', fontWeight: 400 }}>(optional)</span></label>
              <input
                type="text"
                className="input"
                placeholder="e.g. Restocked from supplier"
                value={note}
                onChange={e => setNote(e.target.value)}
              />
            </div>

            {error && (
              <div style={{ color: 'var(--crimson)', fontSize: 13, background: 'var(--crimson-soft)', padding: '8px 12px', borderRadius: 7 }}>
                {error}
              </div>
            )}

            <div style={{ display: 'flex', gap: 8, paddingTop: 4 }}>
              <button type="button" className="btn btn-secondary" onClick={onClose} style={{ flex: 1 }}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={loading} style={{ flex: 1 }}>
                {loading ? <span className="spinner" /> : null}
                {loading ? 'Saving…' : 'Apply Adjustment'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
