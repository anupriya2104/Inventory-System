'use client';
// src/app/products/ProductForm.tsx
import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Save, Package } from 'lucide-react';
import { Product } from '@/types';
import Toast from '@/components/ui/Toast';

interface Props {
  mode: 'create' | 'edit';
  product?: Product;
}

export default function ProductForm({ mode, product }: Props) {
  const router = useRouter();
  const [form, setForm] = useState({
    name: product?.name || '',
    sku: product?.sku || '',
    description: product?.description || '',
    quantityOnHand: product?.quantityOnHand?.toString() || '0',
    costPrice: product?.costPrice?.toString() || '',
    sellingPrice: product?.sellingPrice?.toString() || '',
    lowStockThreshold: product?.lowStockThreshold?.toString() || '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  function set(k: string) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setForm(f => ({ ...f, [k]: e.target.value }));
      if (errors[k]) setErrors(er => ({ ...er, [k]: '' }));
    };
  }

  function validate() {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = 'Name is required';
    if (!form.sku.trim()) errs.sku = 'SKU is required';
    if (form.quantityOnHand === '' || isNaN(Number(form.quantityOnHand))) errs.quantityOnHand = 'Must be a number';
    if (Number(form.quantityOnHand) < 0) errs.quantityOnHand = 'Cannot be negative';
    if (form.costPrice && isNaN(Number(form.costPrice))) errs.costPrice = 'Must be a number';
    if (form.sellingPrice && isNaN(Number(form.sellingPrice))) errs.sellingPrice = 'Must be a number';
    if (form.lowStockThreshold && isNaN(Number(form.lowStockThreshold))) errs.lowStockThreshold = 'Must be a number';
    return errs;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    setLoading(true);
    try {
      const url = mode === 'create' ? '/api/products' : `/api/products/${product!.id}`;
      const method = mode === 'create' ? 'POST' : 'PUT';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!data.success) {
        setToast({ message: data.error || 'Failed to save', type: 'error' });
      } else {
        setToast({ message: mode === 'create' ? 'Product created!' : 'Product updated!', type: 'success' });
        setTimeout(() => router.push('/products'), 800);
      }
    } catch {
      setToast({ message: 'Network error', type: 'error' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <Link href="/products" className="btn btn-ghost btn-sm" style={{ padding: '6px 8px' }}>
            <ArrowLeft size={18} />
          </Link>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, color: 'var(--ink)', margin: 0, marginBottom: 2 }}>
              {mode === 'create' ? 'Add Product' : 'Edit Product'}
            </h1>
            <p style={{ fontSize: 13, color: 'var(--ink-faint)', margin: 0 }}>
              {mode === 'create' ? 'Create a new product in your inventory' : `Editing: ${product?.name}`}
            </p>
          </div>
        </div>
      </div>

      <div className="page-body">
        <div style={{ maxWidth: 680 }}>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {/* Basic info card */}
            <div className="card" style={{ padding: 24 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20, paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
                <Package size={18} color="var(--accent)" />
                <h2 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: 'var(--ink)' }}>Product Details</h2>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div style={{ gridColumn: '1 / -1' }}>
                  <label className="label">Product Name *</label>
                  <input
                    type="text"
                    className={`input ${errors.name ? 'input-error' : ''}`}
                    placeholder="e.g. Blue Widget"
                    value={form.name}
                    onChange={set('name')}
                  />
                  {errors.name && <div style={{ color: 'var(--crimson)', fontSize: 12, marginTop: 4 }}>{errors.name}</div>}
                </div>

                <div>
                  <label className="label">SKU *</label>
                  <input
                    type="text"
                    className={`input ${errors.sku ? 'input-error' : ''}`}
                    placeholder="e.g. BW-001"
                    value={form.sku}
                    onChange={set('sku')}
                    style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}
                  />
                  {errors.sku && <div style={{ color: 'var(--crimson)', fontSize: 12, marginTop: 4 }}>{errors.sku}</div>}
                </div>

                <div>
                  <label className="label">Quantity on Hand *</label>
                  <input
                    type="number"
                    className={`input ${errors.quantityOnHand ? 'input-error' : ''}`}
                    placeholder="0"
                    value={form.quantityOnHand}
                    onChange={set('quantityOnHand')}
                    min={0}
                  />
                  {errors.quantityOnHand && <div style={{ color: 'var(--crimson)', fontSize: 12, marginTop: 4 }}>{errors.quantityOnHand}</div>}
                </div>

                <div style={{ gridColumn: '1 / -1' }}>
                  <label className="label">Description <span style={{ color: 'var(--ink-faint)', fontWeight: 400 }}>(optional)</span></label>
                  <textarea
                    className="input"
                    placeholder="Brief product description…"
                    value={form.description}
                    onChange={set('description')}
                    rows={2}
                    style={{ resize: 'vertical', minHeight: 64 }}
                  />
                </div>
              </div>
            </div>

            {/* Pricing card */}
            <div className="card" style={{ padding: 24 }}>
              <h2 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700, color: 'var(--ink)', paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
                Pricing <span style={{ fontSize: 13, fontWeight: 400, color: 'var(--ink-faint)' }}>(optional)</span>
              </h2>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div>
                  <label className="label">Cost Price</label>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-faint)', fontSize: 14 }}>$</span>
                    <input
                      type="number"
                      className={`input ${errors.costPrice ? 'input-error' : ''}`}
                      placeholder="0.00"
                      value={form.costPrice}
                      onChange={set('costPrice')}
                      min={0}
                      step="0.01"
                      style={{ paddingLeft: 26 }}
                    />
                  </div>
                  {errors.costPrice && <div style={{ color: 'var(--crimson)', fontSize: 12, marginTop: 4 }}>{errors.costPrice}</div>}
                </div>

                <div>
                  <label className="label">Selling Price</label>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-faint)', fontSize: 14 }}>$</span>
                    <input
                      type="number"
                      className={`input ${errors.sellingPrice ? 'input-error' : ''}`}
                      placeholder="0.00"
                      value={form.sellingPrice}
                      onChange={set('sellingPrice')}
                      min={0}
                      step="0.01"
                      style={{ paddingLeft: 26 }}
                    />
                  </div>
                  {errors.sellingPrice && <div style={{ color: 'var(--crimson)', fontSize: 12, marginTop: 4 }}>{errors.sellingPrice}</div>}
                </div>
              </div>
            </div>

            {/* Stock threshold card */}
            <div className="card" style={{ padding: 24 }}>
              <h2 style={{ margin: '0 0 8px', fontSize: 15, fontWeight: 700, color: 'var(--ink)' }}>
                Low Stock Alert
              </h2>
              <p style={{ margin: '0 0 16px', fontSize: 13, color: 'var(--ink-faint)' }}>
                Alert when quantity falls at or below this number. Leave blank to use the global default.
              </p>

              <div style={{ maxWidth: 200 }}>
                <label className="label">Threshold</label>
                <input
                  type="number"
                  className={`input ${errors.lowStockThreshold ? 'input-error' : ''}`}
                  placeholder="Use global default"
                  value={form.lowStockThreshold}
                  onChange={set('lowStockThreshold')}
                  min={0}
                />
                {errors.lowStockThreshold && <div style={{ color: 'var(--crimson)', fontSize: 12, marginTop: 4 }}>{errors.lowStockThreshold}</div>}
              </div>
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: 10, paddingBottom: 8 }}>
              <Link href="/products" className="btn btn-secondary" style={{ minWidth: 100 }}>
                Cancel
              </Link>
              <button type="submit" className="btn btn-primary" disabled={loading} style={{ minWidth: 140 }}>
                {loading ? <span className="spinner" /> : <Save size={15} />}
                {loading ? 'Saving…' : mode === 'create' ? 'Create Product' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </>
  );
}
