// src/app/products/page.tsx
import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import AppShell from '@/components/layout/AppShell';
import ProductsClient from './ProductsClient';

export default async function ProductsPage() {
  const session = await getSession();
  if (!session) redirect('/login');

  const [org, products, settings] = await Promise.all([
    prisma.organization.findUnique({ where: { id: session.orgId } }),
    prisma.product.findMany({
      where: { organizationId: session.orgId, deletedAt: null },
      orderBy: { name: 'asc' },
    }),
    prisma.orgSettings.findUnique({ where: { organizationId: session.orgId } }),
  ]);

  const defaultThreshold = settings?.defaultLowStockThreshold ?? 5;
  const serialized = products.map(p => ({
    ...p,
    isLowStock: p.quantityOnHand <= (p.lowStockThreshold ?? defaultThreshold),
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  }));

  return (
    <AppShell orgName={org?.name || ''} userEmail={session.email}>
      <ProductsClient initialProducts={serialized} defaultThreshold={defaultThreshold} />
    </AppShell>
  );
}
