// src/app/settings/page.tsx
import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import AppShell from '@/components/layout/AppShell';
import SettingsClient from './SettingsClient';

export default async function SettingsPage() {
  const session = await getSession();
  if (!session) redirect('/login');

  const [org, settings] = await Promise.all([
    prisma.organization.findUnique({ where: { id: session.orgId } }),
    prisma.orgSettings.findUnique({ where: { organizationId: session.orgId } }),
  ]);

  return (
    <AppShell orgName={org?.name || ''} userEmail={session.email}>
      <SettingsClient
        defaultLowStockThreshold={settings?.defaultLowStockThreshold ?? 5}
        orgName={org?.name || ''}
        userEmail={session.email}
      />
    </AppShell>
  );
}
