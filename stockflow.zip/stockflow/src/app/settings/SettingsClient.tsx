'use client';
// src/app/settings/SettingsClient.tsx
import { useState, FormEvent } from 'react';
import { Settings, Save, Building2, User } from 'lucide-react';
import Toast from '@/components/ui/Toast';

interface Props {
  defaultLowStockThreshold: number;
  orgName: string;
  userEmail: string;
}

export default function SettingsClient({ defaultLowStockThreshold, orgName, userEmail }: Props) {
  const [threshold, setThreshold] = useState(defaultLowStockThreshold.toString());
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [error, setError] = useState('');

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    const val = parseInt(threshold);
    if (isNaN(val) || val < 0) {
      setError('Threshold must be a non-negative integer');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ defaultLowStockThreshold: val }),
      });
      const data = await res.json();
      if (data.success) {
        setToast({ message: 'Settings saved', type: 'success' });
      } else {
        setToast({ message: data.error || 'Failed to save', type: 'error' });
      }
    } catch {
      setToast({ message: 'Network error', type: 'error' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--paper-warm)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1.5px solid var(--border)' }}>
            <Settings size={20} color="var(--ink-muted)" />
          </div>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: 'var(--ink)', margin: 0, marginBottom: 2 }}>
              Settings
            </h1>
            <p style={{ fontSize: 13, color: 'var(--ink-faint)', margin: 0 }}>
              Manage your organization preferences
            </p>
          </div>
        </div>
      </div>

      <div className="page-body">
        <div style={{ maxWidth: 560, display: 'flex', flexDirection: 'column', gap: 20 }}>

          {/* Org info card */}
          <div className="card animate-slide-up stagger-1" style={{ padding: 24 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20, paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
              <Building2 size={17} color="var(--accent)" />
              <h2 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: 'var(--ink)' }}>Organization</h2>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: 'var(--paper-warm)', borderRadius: 9 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-faint)', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 3 }}>
                    Organization Name
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--ink)' }}>{orgName}</div>
                </div>
                <Building2 size={18} color="var(--border-strong)" />
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: 'var(--paper-warm)', borderRadius: 9 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-faint)', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 3 }}>
                    Account Email
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--ink)' }}>{userEmail}</div>
                </div>
                <User size={18} color="var(--border-strong)" />
              </div>
            </div>
          </div>

          {/* Inventory settings */}
          <div className="card animate-slide-up stagger-2" style={{ padding: 24 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
              <Settings size={17} color="var(--accent)" />
              <h2 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: 'var(--ink)' }}>Inventory Defaults</h2>
            </div>

            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              <div>
                <label className="label">Default Low Stock Threshold</label>
                <p style={{ fontSize: 13, color: 'var(--ink-faint)', margin: '0 0 10px', lineHeight: 1.5 }}>
                  Products without a custom threshold will use this value. A product is marked "low stock" when its quantity is at or below this number.
                </p>

                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <input
                    type="number"
                    className={`input ${error ? 'input-error' : ''}`}
                    value={threshold}
                    onChange={e => { setThreshold(e.target.value); setError(''); }}
                    min={0}
                    style={{ maxWidth: 120, fontFamily: 'var(--font-mono)', fontSize: 18, fontWeight: 600 }}
                  />
                  <span style={{ fontSize: 14, color: 'var(--ink-faint)' }}>units</span>
                </div>

                {error && (
                  <div style={{ color: 'var(--crimson)', fontSize: 13, marginTop: 6 }}>{error}</div>
                )}

                {/* Visual indicator */}
                <div style={{
                  marginTop: 16, padding: '12px 16px', background: 'var(--amber-soft)',
                  borderRadius: 9, border: '1px solid rgba(196,136,42,0.2)',
                  fontSize: 13, color: 'var(--amber)', lineHeight: 1.5,
                }}>
                  <strong>Example:</strong> With a threshold of {parseInt(threshold) || 0}, any product with {parseInt(threshold) || 0} or fewer units will appear as "Low Stock" on the dashboard.
                </div>
              </div>

              <div>
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  {loading ? <span className="spinner" /> : <Save size={15} />}
                  {loading ? 'Saving…' : 'Save Settings'}
                </button>
              </div>
            </form>
          </div>

          {/* Version info */}
          <div style={{ padding: '16px 20px', background: 'var(--paper-warm)', borderRadius: 10, border: '1px solid var(--border)', fontSize: 12, color: 'var(--ink-faint)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span>StockFlow MVP v0.1</span>
            <span style={{ fontFamily: 'var(--font-mono)' }}>Phase 1 Build</span>
          </div>
        </div>
      </div>

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </>
  );
}
