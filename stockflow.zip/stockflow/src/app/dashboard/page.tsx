// src/app/dashboard/page.tsx
import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import AppShell from '@/components/layout/AppShell';
import DashboardClient from './DashboardClient';

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect('/login');

  const [org, products, settings] = await Promise.all([
    prisma.organization.findUnique({ where: { id: session.orgId } }),
    prisma.product.findMany({
      where: { organizationId: session.orgId, deletedAt: null },
      orderBy: { name: 'asc' },
    }),
    prisma.orgSettings.findUnique({ where: { organizationId: session.orgId } }),
  ]);

  const defaultThreshold = settings?.defaultLowStockThreshold ?? 5;
  const totalProducts = products.length;
  const totalQuantity = products.reduce((s, p) => s + p.quantityOnHand, 0);
  const lowStockItems = products
    .filter(p => p.quantityOnHand <= (p.lowStockThreshold ?? defaultThreshold))
    .map(p => ({
      ...p,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
      isLowStock: true,
    }));

  return (
    <AppShell orgName={org?.name || ''} userEmail={session.email}>
      <DashboardClient
        totalProducts={totalProducts}
        totalQuantity={totalQuantity}
        lowStockItems={lowStockItems}
        orgName={org?.name || ''}
        defaultThreshold={defaultThreshold}
      />
    </AppShell>
  );
}
