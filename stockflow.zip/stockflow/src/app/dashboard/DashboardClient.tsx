'use client';
// src/app/dashboard/DashboardClient.tsx
import Link from 'next/link';
import { Package, Layers, AlertTriangle, ArrowRight, TrendingDown } from 'lucide-react';
import { Product } from '@/types';

interface Props {
  totalProducts: number;
  totalQuantity: number;
  lowStockItems: Product[];
  orgName: string;
  defaultThreshold: number;
}

export default function DashboardClient({ totalProducts, totalQuantity, lowStockItems, orgName, defaultThreshold }: Props) {
  return (
    <>
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: 'var(--ink)', margin: 0, marginBottom: 4 }}>
              Dashboard
            </h1>
            <p style={{ fontSize: 14, color: 'var(--ink-faint)', margin: 0 }}>
              Overview of <strong style={{ color: 'var(--ink-muted)' }}>{orgName}</strong>
            </p>
          </div>
          <Link href="/products/new" className="btn btn-primary">
            <Package size={16} />
            Add Product
          </Link>
        </div>
      </div>

      <div className="page-body">
        {/* Stat cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 32 }}>
          <div className="stat-card animate-slide-up stagger-1">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <div className="stat-label">Total Products</div>
              <div style={{ width: 36, height: 36, borderRadius: 9, background: 'var(--accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Package size={18} color="var(--accent)" />
              </div>
            </div>
            <div className="stat-value">{totalProducts}</div>
            <div className="stat-sub">SKUs in catalog</div>
          </div>

          <div className="stat-card animate-slide-up stagger-2">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <div className="stat-label">Total Units</div>
              <div style={{ width: 36, height: 36, borderRadius: 9, background: 'var(--jade-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Layers size={18} color="var(--jade)" />
              </div>
            </div>
            <div className="stat-value">{totalQuantity.toLocaleString()}</div>
            <div className="stat-sub">Units on hand</div>
          </div>

          <div className="stat-card animate-slide-up stagger-3">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <div className="stat-label">Low Stock</div>
              <div style={{ width: 36, height: 36, borderRadius: 9, background: 'var(--crimson-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <AlertTriangle size={18} color="var(--crimson)" />
              </div>
            </div>
            <div className="stat-value" style={{ color: lowStockItems.length > 0 ? 'var(--crimson)' : 'var(--jade)' }}>
              {lowStockItems.length}
            </div>
            <div className="stat-sub">Items need attention</div>
          </div>
        </div>

        {/* Low stock table */}
        <div className="card animate-slide-up stagger-4">
          <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <TrendingDown size={18} color="var(--crimson)" />
              <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>Low Stock Items</h2>
              {lowStockItems.length > 0 && (
                <span style={{
                  background: 'var(--crimson-soft)', color: 'var(--crimson)',
                  fontSize: 12, fontWeight: 700, padding: '2px 8px', borderRadius: 20,
                  fontFamily: 'var(--font-mono)'
                }}>
                  {lowStockItems.length}
                </span>
              )}
            </div>
            <Link href="/products" className="btn btn-ghost btn-sm" style={{ gap: 4 }}>
              View all <ArrowRight size={14} />
            </Link>
          </div>

          {lowStockItems.length === 0 ? (
            <div className="empty-state">
              <div style={{ fontSize: 40, marginBottom: 12 }}>✅</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--ink-muted)', marginBottom: 6 }}>All stocked up!</div>
              <div style={{ fontSize: 14 }}>No items are below their low stock threshold ({defaultThreshold} units default).</div>
            </div>
          ) : (
            <div className="table-container" style={{ border: 'none', borderRadius: 0 }}>
              <table>
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>SKU</th>
                    <th>Qty on Hand</th>
                    <th>Threshold</th>
                    <th>Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {lowStockItems.map(item => {
                    const threshold = item.lowStockThreshold ?? defaultThreshold;
                    const isZero = item.quantityOnHand === 0;
                    return (
                      <tr key={item.id}>
                        <td style={{ fontWeight: 600, color: 'var(--ink)' }}>{item.name}</td>
                        <td>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--ink-muted)' }}>
                            {item.sku}
                          </span>
                        </td>
                        <td>
                          <span style={{
                            fontFamily: 'var(--font-mono)', fontWeight: 700,
                            color: isZero ? 'var(--ink-faint)' : 'var(--crimson)',
                            fontSize: 15
                          }}>
                            {item.quantityOnHand}
                          </span>
                        </td>
                        <td style={{ color: 'var(--ink-muted)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>
                          {threshold}
                        </td>
                        <td>
                          <span className={`badge ${isZero ? 'badge-zero' : 'badge-low-stock'}`}>
                            {isZero ? '⚠ Out of stock' : '↓ Low stock'}
                          </span>
                        </td>
                        <td>
                          <Link
                            href={`/products/${item.id}/edit`}
                            className="btn btn-secondary btn-sm"
                          >
                            Update stock
                          </Link>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
