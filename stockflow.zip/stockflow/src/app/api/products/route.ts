// src/app/api/products/route.ts
import { NextRequest } from 'next/server';
import { getTokenFromRequest } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { ok, err, unauthorized } from '@/lib/api';

export async function GET(req: NextRequest) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  const url = new URL(req.url);
  const search = url.searchParams.get('search') || '';

  const products = await prisma.product.findMany({
    where: {
      organizationId: session.orgId,
      deletedAt: null,
      ...(search ? {
        OR: [
          { name: { contains: search } },
          { sku: { contains: search } },
        ]
      } : {})
    },
    orderBy: { name: 'asc' },
  });

  const settings = await prisma.orgSettings.findUnique({
    where: { organizationId: session.orgId }
  });
  const defaultThreshold = settings?.defaultLowStockThreshold ?? 5;

  const enriched = products.map(p => ({
    ...p,
    isLowStock: p.quantityOnHand <= (p.lowStockThreshold ?? defaultThreshold),
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  }));

  return ok(enriched);
}

export async function POST(req: NextRequest) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  try {
    const body = await req.json();
    const { name, sku, description, quantityOnHand, costPrice, sellingPrice, lowStockThreshold } = body;

    if (!name?.trim()) return err('Name is required');
    if (!sku?.trim()) return err('SKU is required');

    const skuUpper = sku.trim().toUpperCase();

    const existing = await prisma.product.findFirst({
      where: { organizationId: session.orgId, sku: skuUpper, deletedAt: null }
    });
    if (existing) return err('SKU already exists in your organization');

    const product = await prisma.product.create({
      data: {
        organizationId: session.orgId,
        name: name.trim(),
        sku: skuUpper,
        description: description?.trim() || null,
        quantityOnHand: parseInt(quantityOnHand) || 0,
        costPrice: costPrice ? parseFloat(costPrice) : null,
        sellingPrice: sellingPrice ? parseFloat(sellingPrice) : null,
        lowStockThreshold: lowStockThreshold ? parseInt(lowStockThreshold) : null,
      }
    });

    return ok({ ...product, createdAt: product.createdAt.toISOString(), updatedAt: product.updatedAt.toISOString() }, 201);
  } catch (e) {
    console.error(e);
    return err('Failed to create product', 500);
  }
}
