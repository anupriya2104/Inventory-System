// src/app/api/products/[id]/route.ts
import { NextRequest } from 'next/server';
import { getTokenFromRequest } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { ok, err, unauthorized, notFound } from '@/lib/api';

async function getProduct(id: string, orgId: string) {
  return prisma.product.findFirst({
    where: { id, organizationId: orgId, deletedAt: null }
  });
}

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  const product = await getProduct(params.id, session.orgId);
  if (!product) return notFound('Product');

  return ok({
    ...product,
    createdAt: product.createdAt.toISOString(),
    updatedAt: product.updatedAt.toISOString(),
  });
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  const existing = await getProduct(params.id, session.orgId);
  if (!existing) return notFound('Product');

  try {
    const body = await req.json();
    const { name, sku, description, quantityOnHand, costPrice, sellingPrice, lowStockThreshold } = body;

    if (!name?.trim()) return err('Name is required');
    if (!sku?.trim()) return err('SKU is required');

    const skuUpper = sku.trim().toUpperCase();

    // Check SKU uniqueness (excluding self)
    const skuConflict = await prisma.product.findFirst({
      where: {
        organizationId: session.orgId,
        sku: skuUpper,
        deletedAt: null,
        NOT: { id: params.id }
      }
    });
    if (skuConflict) return err('SKU already in use by another product');

    const updated = await prisma.product.update({
      where: { id: params.id },
      data: {
        name: name.trim(),
        sku: skuUpper,
        description: description?.trim() || null,
        quantityOnHand: parseInt(quantityOnHand) || 0,
        costPrice: costPrice !== '' && costPrice != null ? parseFloat(costPrice) : null,
        sellingPrice: sellingPrice !== '' && sellingPrice != null ? parseFloat(sellingPrice) : null,
        lowStockThreshold: lowStockThreshold !== '' && lowStockThreshold != null ? parseInt(lowStockThreshold) : null,
      }
    });

    return ok({
      ...updated,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    });
  } catch (e) {
    console.error(e);
    return err('Failed to update product', 500);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  const existing = await getProduct(params.id, session.orgId);
  if (!existing) return notFound('Product');

  await prisma.product.update({
    where: { id: params.id },
    data: { deletedAt: new Date() }
  });

  return ok({ message: 'Product deleted' });
}
