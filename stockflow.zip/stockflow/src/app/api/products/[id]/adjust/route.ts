// src/app/api/products/[id]/adjust/route.ts
import { NextRequest } from 'next/server';
import { getTokenFromRequest } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { ok, err, unauthorized, notFound } from '@/lib/api';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  const product = await prisma.product.findFirst({
    where: { id: params.id, organizationId: session.orgId, deletedAt: null }
  });
  if (!product) return notFound('Product');

  try {
    const { delta, note } = await req.json();
    const d = parseInt(delta);
    if (isNaN(d) || d === 0) return err('Delta must be a non-zero integer');

    const newQty = product.quantityOnHand + d;
    if (newQty < 0) return err('Stock cannot go below 0');

    const [updated] = await prisma.$transaction([
      prisma.product.update({
        where: { id: params.id },
        data: { quantityOnHand: newQty }
      }),
      prisma.stockAdjustment.create({
        data: {
          organizationId: session.orgId,
          productId: params.id,
          delta: d,
          note: note?.trim() || null,
        }
      })
    ]);

    return ok({
      ...updated,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    });
  } catch (e) {
    console.error(e);
    return err('Failed to adjust stock', 500);
  }
}
