// src/app/api/auth/logout/route.ts
import { cookieName } from '@/lib/auth';
import { ok } from '@/lib/api';

export async function POST() {
  const response = ok({ message: 'Logged out' });
  response.cookies.set(cookieName(), '', { maxAge: 0, path: '/' });
  return response;
}
