// src/app/api/auth/login/route.ts
import { NextRequest } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';
import { signToken, cookieName } from '@/lib/auth';
import { ok, err } from '@/lib/api';

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();
    if (!email || !password) return err('Email and password required');

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
      include: { organization: true }
    });

    if (!user) return err('Invalid credentials', 401);

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return err('Invalid credentials', 401);

    const token = signToken({ userId: user.id, orgId: user.organizationId, email: user.email });

    const response = ok({ email: user.email, orgName: user.organization.name });
    response.cookies.set(cookieName(), token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7,
      path: '/',
    });

    return response;
  } catch (e) {
    console.error(e);
    return err('Internal server error', 500);
  }
}
