// src/app/api/auth/signup/route.ts
import { NextRequest } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';
import { signToken, cookieName } from '@/lib/auth';
import { ok, err } from '@/lib/api';

export async function POST(req: NextRequest) {
  try {
    const { email, password, organizationName } = await req.json();

    if (!email || !password || !organizationName) {
      return err('Email, password, and organization name are required');
    }

    if (password.length < 6) {
      return err('Password must be at least 6 characters');
    }

    const emailLower = email.toLowerCase().trim();

    const existing = await prisma.user.findUnique({ where: { email: emailLower } });
    if (existing) return err('Email already in use');

    const passwordHash = await bcrypt.hash(password, 10);

    const org = await prisma.organization.create({
      data: {
        name: organizationName.trim(),
        settings: {
          create: { defaultLowStockThreshold: 5 }
        },
        users: {
          create: { email: emailLower, passwordHash }
        }
      },
      include: { users: true }
    });

    const user = org.users[0];
    const token = signToken({ userId: user.id, orgId: org.id, email: user.email });

    const response = ok({ email: user.email, orgName: org.name });
    response.cookies.set(cookieName(), token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7,
      path: '/',
    });

    return response;
  } catch (e) {
    console.error(e);
    return err('Internal server error', 500);
  }
}
