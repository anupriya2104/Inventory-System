// src/app/api/auth/me/route.ts
import { NextRequest } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { ok, unauthorized } from '@/lib/api';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return unauthorized();
  return ok({
    id: user.id,
    email: user.email,
    organizationId: user.organizationId,
    organization: {
      id: user.organization.id,
      name: user.organization.name,
      settings: user.organization.settings,
    }
  });
}
