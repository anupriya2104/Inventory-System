// src/app/api/settings/route.ts
import { NextRequest } from 'next/server';
import { getTokenFromRequest } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { ok, err, unauthorized } from '@/lib/api';

export async function GET(req: NextRequest) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  const settings = await prisma.orgSettings.findUnique({
    where: { organizationId: session.orgId }
  });

  return ok({ defaultLowStockThreshold: settings?.defaultLowStockThreshold ?? 5 });
}

export async function PUT(req: NextRequest) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  try {
    const { defaultLowStockThreshold } = await req.json();
    const val = parseInt(defaultLowStockThreshold);
    if (isNaN(val) || val < 0) return err('Threshold must be a non-negative integer');

    const settings = await prisma.orgSettings.upsert({
      where: { organizationId: session.orgId },
      update: { defaultLowStockThreshold: val },
      create: { organizationId: session.orgId, defaultLowStockThreshold: val }
    });

    return ok({ defaultLowStockThreshold: settings.defaultLowStockThreshold });
  } catch (e) {
    console.error(e);
    return err('Failed to update settings', 500);
  }
}
