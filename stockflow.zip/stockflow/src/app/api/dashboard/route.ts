// src/app/api/dashboard/route.ts
import { NextRequest } from 'next/server';
import { getTokenFromRequest } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { ok, unauthorized } from '@/lib/api';

export async function GET(req: NextRequest) {
  const session = getTokenFromRequest(req);
  if (!session) return unauthorized();

  const { orgId } = session;

  const [products, settings] = await Promise.all([
    prisma.product.findMany({
      where: { organizationId: orgId, deletedAt: null },
      orderBy: { name: 'asc' },
    }),
    prisma.orgSettings.findUnique({ where: { organizationId: orgId } }),
  ]);

  const org = await prisma.organization.findUnique({ where: { id: orgId } });
  const defaultThreshold = settings?.defaultLowStockThreshold ?? 5;

  const totalProducts = products.length;
  const totalQuantity = products.reduce((s, p) => s + p.quantityOnHand, 0);

  const lowStockItems = products
    .filter(p => {
      const threshold = p.lowStockThreshold ?? defaultThreshold;
      return p.quantityOnHand <= threshold;
    })
    .map(p => ({
      ...p,
      isLowStock: true,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    }));

  return ok({
    totalProducts,
    totalQuantity,
    lowStockItems,
    orgName: org?.name || '',
    defaultThreshold,
  });
}
