// src/lib/api.ts
import { NextResponse } from 'next/server';

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

export function err(message: string, status = 400) {
  return NextResponse.json({ success: false, error: message }, { status });
}

export function unauthorized() {
  return err('Unauthorized', 401);
}

export function notFound(what = 'Resource') {
  return err(`${what} not found`, 404);
}
