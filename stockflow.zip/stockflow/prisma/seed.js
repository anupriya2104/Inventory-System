// prisma/seed.js
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash('password123', 10);

  const org = await prisma.organization.create({
    data: {
      name: 'Demo Store',
      settings: {
        create: { defaultLowStockThreshold: 5 }
      },
      users: {
        create: {
          email: 'demo@stockflow.com',
          passwordHash,
        }
      },
      products: {
        createMany: {
          data: [
            { name: 'Blue Widget', sku: 'BW-001', quantityOnHand: 150, costPrice: 4.99, sellingPrice: 12.99, lowStockThreshold: 20 },
            { name: 'Red Gadget', sku: 'RG-002', quantityOnHand: 3, costPrice: 14.99, sellingPrice: 34.99, lowStockThreshold: 10 },
            { name: 'Green Thingamajig', sku: 'GT-003', quantityOnHand: 8, costPrice: 2.49, sellingPrice: 7.99, lowStockThreshold: 15 },
            { name: 'Purple Doohickey', sku: 'PD-004', quantityOnHand: 42, costPrice: 9.99, sellingPrice: 24.99, lowStockThreshold: 5 },
            { name: 'Yellow Whatchamacallit', sku: 'YW-005', quantityOnHand: 2, costPrice: 1.99, sellingPrice: 5.99, lowStockThreshold: 8 },
            { name: 'Orange Sprocket', sku: 'OS-006', quantityOnHand: 77, costPrice: 0.99, sellingPrice: 2.99 },
            { name: 'Silver Contraption', sku: 'SC-007', quantityOnHand: 0, costPrice: 29.99, sellingPrice: 79.99, lowStockThreshold: 5 },
          ]
        }
      }
    }
  });

  console.log(`✅ Seeded org: ${org.name}`);
  console.log(`📧 Login: demo@stockflow.com / password123`);
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
